# Pixel Champions — Fan Edition (v1.0 playable prototype)

무료 비공식 포켓몬 팬게임의 **독립 실행형 브라우저 프로토타입**. 2D 도트 전투·3마리 팀 편성·5장 스토리·CPU 전투·타입 상성·기기별 저장·PokéAPI 연동을 포함합니다.

## 실행

`index.html`을 웹 서버로 제공하세요. 예: `python -m http.server 8080` 실행 후 `http://localhost:8080/` 접속. GitHub Pages에서도 동작합니다.

## GitHub Pages

1. 새 **공개** 저장소 만들고 이 폴더의 내용을 저장소 최상위에 업로드합니다. 기본 브랜치는 `main`으로 설정합니다.
2. Settings → Pages → Build and deployment → Source → **GitHub Actions**를 선택합니다.
3. Actions의 `Deploy static game to GitHub Pages`가 성공하면 Pages URL을 엽니다.

## 현재 구현과 한계

- 18종 선택 후보, PokéAPI에서 타입/기본 능력치 조회(연결 실패 시 로컬 기본값 대체), 3대3 싱글 CPU 배틀, 5개 스토리 단계, 연습 배틀, 로컬 저장.
- 타입 상성 계산은 일부 공격 타입에 대한 축약 테이블입니다. 기술 이름/위력은 자체 제작 데이터이며 원작 기술/특성/도구/교체 우선도/상태이상/날씨/테라스탈/메가진화 등의 규칙은 구현되지 않았습니다.
- **Pokémon Showdown 공식 배틀 시뮬레이터가 아닙니다.** 진짜 Showdown 규칙, 6대6, 실시간 PvP, 레이팅·계정·매치메이킹은 별도 서버가 필요합니다. GitHub Pages만으로는 서버 동기화/안티치트 구현이 불가능합니다.
- 1.0은 플레이 가능한 **프로토타입 릴리스**를 의미하며 포켓몬 챔피언스의 완전한 리메이크나 정식 출시 수준을 의미하지 않습니다.

## 권리와 출처

이 프로젝트는 무료·비공식 팬 프로젝트이며 Pokémon, Nintendo, Game Freak, Creatures 또는 Pokémon Champions의 공식 제작진과 연관되지 않습니다. Pokémon 이미지, 명칭 및 캐릭터 권리는 원 권리자에게 있습니다. PokéAPI의 프로그램 라이선스가 포켓몬 IP/스프라이트의 사용 허락을 의미하지 않습니다. 공개 배포 전 자산 사용 권리 검토가 필요합니다.

- https://pokeapi.co/ · https://github.com/PokeAPI/pokeapi
- https://github.com/PokeAPI/sprites
- https://github.com/smogon/pokemon-showdown (향후 서버 배틀 엔진 연동 연구용; 현재 코드 포함 안 함)

## 개발 계획

- Showdown 서버+클라이언트 연동 및 공식에 가까운 턴 처리
- 대사/이벤트 씬, 도트 맵/타일 이동, 인물 대화, BGM, 도감 다국어
- 네트워크 PvP, 룸 코드, 안전한 서버 측 전투 판정
- 자체 제작/사용허락된 이미지 자산으로 교체
